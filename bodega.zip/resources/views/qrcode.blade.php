<div class="visible-print text-center">
    <img src="data:image/png;base64, {!! $qrcode !!}">
    <div class="border"> 
        <h1 class="text-center">{{ $url }}</h1>
    </div>
</div>
