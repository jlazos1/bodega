<a href="/">
    <img src="img/logognv2.png" alt="">
</a>
