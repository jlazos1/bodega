

<?php $__env->startSection('title', 'Tarjetas de Juegos'); ?>

<?php $__env->startSection('content_header'); ?>
    <?php if (app(\Illuminate\Contracts\Auth\Access\Gate::class)->check('admin.game-boards.create')): ?>
        <a href="<?php echo e(route('admin.game-boards.create')); ?>" class="btn btn-primary mb-2 float-right">Nuevo</a>
    <?php endif; ?>
    <h1>Tarjetas de Juegos</h1>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('content'); ?>
    <?php
if (! isset($_instance)) {
    $html = \Livewire\Livewire::mount('admin.games-boards-index')->html();
} elseif ($_instance->childHasBeenRendered('Y0kLrrN')) {
    $componentId = $_instance->getRenderedChildComponentId('Y0kLrrN');
    $componentTag = $_instance->getRenderedChildComponentTagName('Y0kLrrN');
    $html = \Livewire\Livewire::dummyMount($componentId, $componentTag);
    $_instance->preserveRenderedChild('Y0kLrrN');
} else {
    $response = \Livewire\Livewire::mount('admin.games-boards-index');
    $html = $response->html();
    $_instance->logRenderedChild('Y0kLrrN', $response->id(), \Livewire\Livewire::getRootElementTagName($html));
}
echo $html;
?>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('css'); ?>
    <link rel="stylesheet" href="/css/admin_custom.css">
    <script src="https://kit.fontawesome.com/3ace52d1a2.js" crossorigin="anonymous"></script>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('js'); ?>
    <?php echo \Livewire\Livewire::scripts(); ?>

<?php $__env->stopSection(); ?>

<?php echo $__env->make('adminlte::page', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\bodega\resources\views/admin/games_boards/index.blade.php ENDPATH**/ ?>