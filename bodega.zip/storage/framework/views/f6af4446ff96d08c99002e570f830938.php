<?php if(session('info')): ?>
    <div class="alert alert-success">
        <strong>
            <?php echo e(session('info')); ?>

        </strong>
    </div>
<?php endif; ?>

<div>
    <div class="card">
        <div class="card-header">
            <input wire:model="search" type="text" class="form-control" placeholder="Filtrar">
        </div>


        <?php if($maintenances->count()): ?>
            <div class="card-body">
                <table class="table table-striped">
                    <thead>
                        <tr>
                            <th>ID</th>
                            <th>Fecha</th>
                            <th>Máquina</th>
                            <th>Encargado</th>
                            <th></th>
                        </tr>
                    </thead>
                    <tbody>
                        <?php $__currentLoopData = $maintenances; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $maintenance): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <tr>
                                <td><?php echo e($maintenance->id); ?></td>
                                <td><?php echo e(\Carbon\Carbon::parse($maintenance->date)->format('d-m-Y')); ?></td>
                                <td><?php echo e($maintenance->machine_name); ?></td>
                                <td><?php echo e($maintenance->user_name); ?></td>
                                <td width="10px">
                                    <?php if (app(\Illuminate\Contracts\Auth\Access\Gate::class)->check('admin.maintenances.show')): ?>
                                        <a href="<?php echo e(route('admin.maintenances.show', $maintenance->id)); ?>"
                                            class="btn btn-primary fa fa-eye"></a>
                                    <?php endif; ?>
                                </td>
                            </tr>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    </tbody>
                </table>
            </div>
            <div class="card-footer">
                <?php echo e($maintenances->links()); ?>

            </div>
        <?php else: ?>
            <div class="card-body">
                <strong>No hay registros</strong>
            </div>
        <?php endif; ?>

    </div>
</div>
<?php /**PATH C:\xampp\htdocs\bodega\resources\views/livewire/admin/maintenances-index.blade.php ENDPATH**/ ?>