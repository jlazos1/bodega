

<?php $__env->startSection('title', 'Arriendos'); ?>

<?php $__env->startSection('content_header'); ?>
    <?php if (app(\Illuminate\Contracts\Auth\Access\Gate::class)->check('loans.checkReturn')): ?>
        <a href="<?php echo e(route('loans.checkReturn')); ?>" class="btn btn-primary mb-2 float-right">Comprobar Estado</a>
    <?php endif; ?>
    <?php if (app(\Illuminate\Contracts\Auth\Access\Gate::class)->check('admin.loans.create')): ?>
        <a href="<?php echo e(route('admin.loans.create')); ?>" class="btn btn-primary mb-2 float-right mr-2">Nuevo</a>
    <?php endif; ?>
    <h1>Arriendos</h1>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('content'); ?>
    <?php
if (! isset($_instance)) {
    $html = \Livewire\Livewire::mount('admin.loans-index')->html();
} elseif ($_instance->childHasBeenRendered('NxlOwTK')) {
    $componentId = $_instance->getRenderedChildComponentId('NxlOwTK');
    $componentTag = $_instance->getRenderedChildComponentTagName('NxlOwTK');
    $html = \Livewire\Livewire::dummyMount($componentId, $componentTag);
    $_instance->preserveRenderedChild('NxlOwTK');
} else {
    $response = \Livewire\Livewire::mount('admin.loans-index');
    $html = $response->html();
    $_instance->logRenderedChild('NxlOwTK', $response->id(), \Livewire\Livewire::getRootElementTagName($html));
}
echo $html;
?>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('css'); ?>
    <link rel="stylesheet" href="/css/admin_custom.css">
    <script src="https://kit.fontawesome.com/3ace52d1a2.js" crossorigin="anonymous"></script>

<?php $__env->stopSection(); ?>

<?php $__env->startSection('js'); ?>
    <?php echo \Livewire\Livewire::scripts(); ?>

<?php $__env->stopSection(); ?>

<?php echo $__env->make('adminlte::page', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\bodega\resources\views/admin/loans/index.blade.php ENDPATH**/ ?>