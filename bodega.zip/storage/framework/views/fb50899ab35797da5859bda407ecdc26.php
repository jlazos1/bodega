

<?php $__env->startSection('title', 'Categorías de Productos'); ?>

<?php $__env->startSection('content_header'); ?>
    <?php if (app(\Illuminate\Contracts\Auth\Access\Gate::class)->check('admin.product_types.create')): ?>
        <a href="<?php echo e(route('admin.product_types.create')); ?>" class="btn btn-primary mb-2 float-right">Nuevo</a>
    <?php endif; ?>
    <h1>Categorías de Productos</h1>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('content'); ?>
    <?php
if (! isset($_instance)) {
    $html = \Livewire\Livewire::mount('admin.product-types-index')->html();
} elseif ($_instance->childHasBeenRendered('Z6Wer2x')) {
    $componentId = $_instance->getRenderedChildComponentId('Z6Wer2x');
    $componentTag = $_instance->getRenderedChildComponentTagName('Z6Wer2x');
    $html = \Livewire\Livewire::dummyMount($componentId, $componentTag);
    $_instance->preserveRenderedChild('Z6Wer2x');
} else {
    $response = \Livewire\Livewire::mount('admin.product-types-index');
    $html = $response->html();
    $_instance->logRenderedChild('Z6Wer2x', $response->id(), \Livewire\Livewire::getRootElementTagName($html));
}
echo $html;
?>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('css'); ?>
    <link rel="stylesheet" href="/css/admin_custom.css">
    <script src="https://kit.fontawesome.com/3ace52d1a2.js" crossorigin="anonymous"></script>

<?php $__env->stopSection(); ?>

<?php $__env->startSection('js'); ?>
    <?php echo \Livewire\Livewire::scripts(); ?>

<?php $__env->stopSection(); ?>

<?php echo $__env->make('adminlte::page', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\bodega\resources\views/admin/product_types/index.blade.php ENDPATH**/ ?>