<?php if(session('info')): ?>
    <div class="alert alert-success">
        <strong>
            <?php echo e(session('info')); ?>

        </strong>
    </div>
<?php endif; ?>

<div>
    <div class="card">
        <div class="card-header">
            <input wire:model="search" type="text" class="form-control mb-2" placeholder="Filtrar">

            <div class="mt-3">
                <div class="float-left mb-20" style='width: 49%'>
                    <label for="">Fecha Inicial</label>
                    <input wire:model="from_date" type="date" class="form-control mb-2" placeholder="Filtrar">
                </div>
                <div class="float-right" style='width: 49%'>
                    <label for="">Fecha Final</label>
                    <input wire:model="to_date" type="date" class="form-control" placeholder="Filtrar">
                </div>
            </div>

        </div>

        <?php if($relocations->count()): ?>
            <div class="card-body">
                <table class="table table-striped">
                    <thead>
                        <tr>
                            <th>ID</th>
                            <th>Fecha</th>
                            <th>Origen</th>
                            <th>Destino</th>
                            <th></th>
                        </tr>
                    </thead>
                    <tbody>
                        <?php $__currentLoopData = $relocations; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $relo): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <tr>
                                <td><?php echo e($relo->id); ?></td>
                                <td><?php echo e($relo->date); ?></td>
                                <td><?php echo e($relo->origin_name); ?></td>
                                <td><?php echo e($relo->destination_name); ?></td>
                                <td width="10px">
                                    <?php if (app(\Illuminate\Contracts\Auth\Access\Gate::class)->check('admin.machines-relocations.show')): ?>
                                        <a href="<?php echo e(route('admin.machines-relocations.show', $relo->id)); ?>"
                                            class="btn btn-primary fa fa-eye"></a>
                                    <?php endif; ?>
                                </td>
                            </tr>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    </tbody>
                </table>
            </div>
            <div class="card-footer">
                <?php echo e($relocations->links()); ?>

            </div>
        <?php else: ?>
            <div class="card-body">
                <strong>No hay registros</strong>
            </div>
        <?php endif; ?>

    </div>
</div>
<?php /**PATH C:\xampp\htdocs\bodega\resources\views/livewire/admin/machines-relocation-index.blade.php ENDPATH**/ ?>