

<?php $__env->startSection('title', 'Usuarios'); ?>

<?php $__env->startSection('content_header'); ?>
    <h1>Modificar información de usuario</h1>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('content'); ?>

    <?php if(session('info')): ?>
        <div class="alert alert-success">
            <strong>
                <?php echo e(session('info')); ?>

            </strong>
        </div>
    <?php endif; ?>

    <div class="card">
        <div class="card-body">
            <?php echo Form::model($user, ['route' => ['admin.users.update', $user], 'method' => 'put']); ?>


            <?php echo Form::label('name', 'Nombre', ['class' => 'h5']); ?>

            <?php echo Form::text('name', $user->name, ['class' => 'form-control mb-2']); ?>

            <?php $__errorArgs = ['name'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                <small style="color: red"><?php echo e($message); ?></small><br>
            <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>

            <?php echo Form::label('email', 'Email', ['class' => 'h5']); ?>

            <?php echo Form::text('email', $user->email, ['class' => 'form-control mb-2']); ?>

            <?php $__errorArgs = ['email'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                <small style="color: red"><?php echo e($message); ?></small><br>
            <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>

            <?php echo Form::label('branch', 'Sucursal', ['class' => 'h5']); ?>

            <?php echo Form::select('branch_id', $branches, null, [
                'class' => 'select-branch form-control mb-2',
                'placeholder' => 'Seleccione una Sucursal',
            ]); ?>

            <?php $__errorArgs = ['branch_id'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                <small style="color: red"><?php echo e($message); ?></small><br>
            <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>


            <h2 class="h5 mt-4">Listado de roles</h2>

            <?php $__currentLoopData = $roles; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $role): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <div>
                    <label>
                        <?php echo Form::checkbox('roles[]', $role->id, null, ['class' => 'mr-1']); ?>

                        <?php echo e($role->name); ?>

                    </label>
                </div>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

            <?php echo Form::submit('Guardar', ['class' => 'btn btn-primary']); ?>


            <?php echo Form::close(); ?>


        </div>
    </div>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('css'); ?>
    <link rel="stylesheet" href="/css/styles.css">
<?php $__env->stopSection(); ?>

<?php $__env->startSection('js'); ?>
    <?php echo \Livewire\Livewire::scripts(); ?>


    <script>
       $(document).ready(function() {
            let select2 = $('.select-branch').select2();
            select2.data('select2').$selection.css('height', '35px');
        });
    </script>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('adminlte::page', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\bodega\resources\views/admin/users/edit.blade.php ENDPATH**/ ?>