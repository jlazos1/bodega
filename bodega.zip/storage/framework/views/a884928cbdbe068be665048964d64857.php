<?php if(session('info')): ?>
    <div class="alert alert-success">
        <strong>
            <?php echo e(session('info')); ?>

        </strong>
    </div>
<?php endif; ?>

<div>
    <div class="card">
        <div class="card-header">
            <input wire:model="search" type="text" class="form-control" placeholder="Filtrar">
        </div>

        <?php if($customers->count()): ?>
            <div class="card-body">
                <table class="table table-striped">
                    <thead>
                        <tr>
                            <th>ID</th>
                            <th>Nombre</th>
                            <th>Email</th>
                            <th>Teléfono</th>
                            <th>Ciudad</th>
                            <th></th>
                        </tr>
                    </thead>
                    <tbody>
                        <?php $__currentLoopData = $customers; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $customer): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <tr>
                                <td><?php echo e($customer->id); ?></td>
                                <td><?php echo e($customer->name); ?></td>
                                <td><?php echo e($customer->email); ?></td>
                                <td><?php echo e($customer->phone); ?></td>
                                <td><?php echo e($customer->city_name); ?></td>

                                <td width="10px">
                                    <?php if (app(\Illuminate\Contracts\Auth\Access\Gate::class)->check('admin.customers.edit')): ?>
                                        <a href="<?php echo e(route('admin.customers.edit', $customer->id)); ?>"
                                            class="btn btn-primary fa fa-pen-to-square"></a>
                                    <?php endif; ?>
                                </td>
                            </tr>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    </tbody>
                </table>
            </div>
            <div class="card-footer">
                <?php echo e($customers->links()); ?>

            </div>
        <?php else: ?>
            <div class="card-body">
                <strong>No hay registros</strong>
            </div>
        <?php endif; ?>

    </div>
</div>
<?php /**PATH C:\xampp\htdocs\bodega\resources\views/livewire/admin/customers-index.blade.php ENDPATH**/ ?>