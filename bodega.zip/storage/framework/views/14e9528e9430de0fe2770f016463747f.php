

<?php $__env->startSection('title', 'Modelos de Activos'); ?>

<?php $__env->startSection('content_header'); ?>
    <?php if (app(\Illuminate\Contracts\Auth\Access\Gate::class)->check('admin.asset_models.create')): ?>
        <a href="<?php echo e(route('admin.asset_models.create')); ?>" class="btn btn-primary mb-2 float-right">Nuevo</a>
    <?php endif; ?>
    <h1>Modelos de Activos</h1>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('content'); ?>
    <?php
if (! isset($_instance)) {
    $html = \Livewire\Livewire::mount('admin.asset-models-index')->html();
} elseif ($_instance->childHasBeenRendered('3dTc5hR')) {
    $componentId = $_instance->getRenderedChildComponentId('3dTc5hR');
    $componentTag = $_instance->getRenderedChildComponentTagName('3dTc5hR');
    $html = \Livewire\Livewire::dummyMount($componentId, $componentTag);
    $_instance->preserveRenderedChild('3dTc5hR');
} else {
    $response = \Livewire\Livewire::mount('admin.asset-models-index');
    $html = $response->html();
    $_instance->logRenderedChild('3dTc5hR', $response->id(), \Livewire\Livewire::getRootElementTagName($html));
}
echo $html;
?>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('css'); ?>
    <link rel="stylesheet" href="/css/admin_custom.css">
    <script src="https://kit.fontawesome.com/3ace52d1a2.js" crossorigin="anonymous"></script>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('js'); ?>
    <?php echo \Livewire\Livewire::scripts(); ?>

<?php $__env->stopSection(); ?>

<?php echo $__env->make('adminlte::page', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\bodega\resources\views/admin/asset_models/index.blade.php ENDPATH**/ ?>