

<?php $__env->startSection('title', 'Stock por Sucursal'); ?>

<?php $__env->startSection('content_header'); ?>
    <h1>Stock por Sucursal</h1>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('content'); ?>
    <?php
if (! isset($_instance)) {
    $html = \Livewire\Livewire::mount('admin.stock-branch-index')->html();
} elseif ($_instance->childHasBeenRendered('UyB9ESP')) {
    $componentId = $_instance->getRenderedChildComponentId('UyB9ESP');
    $componentTag = $_instance->getRenderedChildComponentTagName('UyB9ESP');
    $html = \Livewire\Livewire::dummyMount($componentId, $componentTag);
    $_instance->preserveRenderedChild('UyB9ESP');
} else {
    $response = \Livewire\Livewire::mount('admin.stock-branch-index');
    $html = $response->html();
    $_instance->logRenderedChild('UyB9ESP', $response->id(), \Livewire\Livewire::getRootElementTagName($html));
}
echo $html;
?>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('css'); ?>
    <link rel="stylesheet" href="/css/admin_custom.css">
    <script src="https://kit.fontawesome.com/3ace52d1a2.js" crossorigin="anonymous"></script>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('js'); ?>
    <?php echo \Livewire\Livewire::scripts(); ?>

<?php $__env->stopSection(); ?>

<?php echo $__env->make('adminlte::page', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\bodega\resources\views/admin/products_branch/index.blade.php ENDPATH**/ ?>