

<?php $__env->startSection('title', 'Tipo de Activo'); ?>

<?php $__env->startSection('content_header'); ?>
    <h1>Editar Tipo de Activo</h1>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('content'); ?>

    <div class="card">
        <div class="card-body">
            <?php echo Form::token(); ?>

            <?php echo Form::open(['route' => ['admin.machines.update', $machine->id], 'method' => 'put']); ?>


            <?php echo Form::label('name', 'Nombre', ['class' => 'h5']); ?>

            <?php echo Form::text('name', $machine->name, ['class' => 'form-control mb-2']); ?>

            <?php $__errorArgs = ['name'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                <small style="color: red"><?php echo e($message); ?></small><br>
            <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>

            <?php echo Form::label('value', 'Valor Monetario', ['class' => 'h5']); ?>

            <?php echo Form::number('value', $machine->value, ['class' => 'form-control mb-2']); ?>

            <?php $__errorArgs = ['value'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                <small style="color: red"><?php echo e($message); ?></small><br>
            <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>

            <?php echo Form::label('games_board_id', 'Tarjeta de Juego', ['class' => 'h5']); ?>

            <?php echo Form::select('games_board_id', $games_boards, $machine->games_board_id, [
                'class' => 'form-control mb-2 games_boards_select',
                'placeholder' => 'Seleccione una Tarjeta de Juego',
            ]); ?>

            <?php $__errorArgs = ['games_boards_id'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                <small style="color: red"><?php echo e($message); ?></small><br>
            <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>

            <?php echo Form::label('branch_id', 'Sucursal', ['class' => 'h5']); ?>

            <?php echo Form::select('branch_id', $branches, $machine->branch_id, [
                'class' => 'form-control mb-2 branch-select',
                'placeholder' => 'Seleccione una Sucursal',
            ]); ?>

            <?php $__errorArgs = ['branch_id'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                <small style="color: red"><?php echo e($message); ?></small><br>
            <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>

            <?php echo Form::submit('Guardar', ['class' => 'btn btn-primary mt-4']); ?>


            <?php echo Form::close(); ?>


        </div>
    </div>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('css'); ?>
    <link rel="stylesheet" href="/css/admin_custom.css">
<?php $__env->stopSection(); ?>

<?php $__env->startSection('js'); ?>
    <?php echo \Livewire\Livewire::scripts(); ?>

    <script>
        $(document).ready(function() {
            $('.games_boards_select').select2();
        });
    </script>
    <script>
        $(document).ready(function() {
            $('.branch-select').select2();
        });
    </script>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('adminlte::page', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\bodega\resources\views/admin/machines/edit.blade.php ENDPATH**/ ?>