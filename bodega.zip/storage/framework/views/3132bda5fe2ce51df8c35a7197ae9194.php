

<?php $__env->startSection('title', 'Proveedores'); ?>

<?php $__env->startSection('content_header'); ?>
    <?php if (app(\Illuminate\Contracts\Auth\Access\Gate::class)->check('admin.providers.create')): ?>
        <a href="<?php echo e(route('admin.providers.create')); ?>" class="btn btn-primary mb-2 float-right">Nuevo</a>
    <?php endif; ?>

    <h1>Lista de Proveedores</h1>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('content'); ?>
    <?php
if (! isset($_instance)) {
    $html = \Livewire\Livewire::mount('admin.providers-index')->html();
} elseif ($_instance->childHasBeenRendered('dgFeXYo')) {
    $componentId = $_instance->getRenderedChildComponentId('dgFeXYo');
    $componentTag = $_instance->getRenderedChildComponentTagName('dgFeXYo');
    $html = \Livewire\Livewire::dummyMount($componentId, $componentTag);
    $_instance->preserveRenderedChild('dgFeXYo');
} else {
    $response = \Livewire\Livewire::mount('admin.providers-index');
    $html = $response->html();
    $_instance->logRenderedChild('dgFeXYo', $response->id(), \Livewire\Livewire::getRootElementTagName($html));
}
echo $html;
?>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('css'); ?>
    <link rel="stylesheet" href="/css/admin_custom.css">
    <script src="https://kit.fontawesome.com/3ace52d1a2.js" crossorigin="anonymous"></script>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('js'); ?>
    <?php echo \Livewire\Livewire::scripts(); ?>

<?php $__env->stopSection(); ?>

<?php echo $__env->make('adminlte::page', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\bodega\resources\views/admin/providers/index.blade.php ENDPATH**/ ?>