

<?php $__env->startSection('title', 'Productos'); ?>

<?php $__env->startSection('content_header'); ?>
    <?php if (app(\Illuminate\Contracts\Auth\Access\Gate::class)->check('admin.products.create')): ?>
        <a href="<?php echo e(route('admin.products.create')); ?>" class="btn btn-primary mb-2 float-right">Nuevo</a>
    <?php endif; ?>
    <h1>Productos</h1>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('content'); ?>
    <?php
if (! isset($_instance)) {
    $html = \Livewire\Livewire::mount('admin.products-index')->html();
} elseif ($_instance->childHasBeenRendered('YdON6hz')) {
    $componentId = $_instance->getRenderedChildComponentId('YdON6hz');
    $componentTag = $_instance->getRenderedChildComponentTagName('YdON6hz');
    $html = \Livewire\Livewire::dummyMount($componentId, $componentTag);
    $_instance->preserveRenderedChild('YdON6hz');
} else {
    $response = \Livewire\Livewire::mount('admin.products-index');
    $html = $response->html();
    $_instance->logRenderedChild('YdON6hz', $response->id(), \Livewire\Livewire::getRootElementTagName($html));
}
echo $html;
?>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('css'); ?>
    <link rel="stylesheet" href="/css/admin_custom.css">
    <script src="https://kit.fontawesome.com/3ace52d1a2.js" crossorigin="anonymous"></script>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('js'); ?>
    <?php echo \Livewire\Livewire::scripts(); ?>

<?php $__env->stopSection(); ?>

<?php echo $__env->make('adminlte::page', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\bodega\resources\views/admin/products/index.blade.php ENDPATH**/ ?>