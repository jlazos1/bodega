

<?php $__env->startSection('title', 'Tipo de Producto'); ?>

<?php $__env->startSection('content_header'); ?>
    <h1>Nuevo Tipo de Producto</h1>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('content'); ?>

    <div class="card">
        <div class="card-body">
            <?php echo Form::token(); ?>

            <?php echo Form::open(['route' => 'admin.product_types.store', 'method' => 'post']); ?>


            <?php echo Form::label('name', 'Nombre', ['class' => 'h5']); ?>

            <?php echo Form::text('name', null, ['class' => 'form-control mb-2']); ?>

            <?php $__errorArgs = ['name'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                <small style="color: red"><?php echo e($message); ?></small><br>
            <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>

            <?php echo Form::submit('Guardar', ['class' => 'btn btn-primary mt-4']); ?>


            <?php echo Form::close(); ?>


        </div>
    </div>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('css'); ?>
    <link rel="stylesheet" href="/css/admin_custom.css">
<?php $__env->stopSection(); ?>

<?php $__env->startSection('js'); ?>
    <?php echo \Livewire\Livewire::scripts(); ?>


<?php $__env->stopSection(); ?>

<?php echo $__env->make('adminlte::page', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\bodega\resources\views/admin/product_types/create.blade.php ENDPATH**/ ?>