

<?php $__env->startSection('title', 'Entradas'); ?>

<?php $__env->startSection('content_header'); ?>
    <h1>Entrada</h1>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('content'); ?>

    <div class="card">
        <div class="card-body">

            <?php echo Form::label('branch_id', 'Sucursal', ['class' => 'h5']); ?>

            <?php echo Form::label('branch_id', $branch_name, ['class' => 'form-control mb-2']); ?>


            <?php echo Form::label('date', 'Fecha', ['class' => 'h5']); ?>

            <?php echo Form::label('date', \Carbon\Carbon::parse($input->date)->format('d-m-Y'), ['class' => 'form-control mb-2']); ?>


            <?php echo Form::label('provider_id', 'Proveedor', ['class' => 'h5']); ?>

            <?php echo Form::label('date', $provider_name, ['class' => 'form-control mb-2']); ?>


            <?php echo Form::label('document_type_id', 'Tipo de Documento', ['class' => 'h5']); ?>

            <?php echo Form::label('date', $type_doc, ['class' => 'form-control mb-2']); ?>


            <?php echo Form::label('doc_number', 'Número de Documento', ['class' => 'h5']); ?>

            <?php if($input->doc_number == null): ?>
                <?php echo Form::label('date', 'Sin Información', ['class' => 'form-control mb-2']); ?>

            <?php else: ?>
                <?php echo Form::label('date', $input->doc_number, ['class' => 'form-control mb-2']); ?>

            <?php endif; ?>

        </div>

        <div class="card-body">
            <h2>Productos</h2>
            <table class="table table-striped mt-2">
                <thead>
                    <tr>
                        <th>Nombre</th>
                        <th>Cantidad</th>
                        <th>P. Unitario</th>
                        <th>Total</th>
                    </tr>
                </thead>
                <tbody>
                    <?php $__currentLoopData = $productsAdd; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $product): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <tr>
                            <td><?php echo e($product->product_name); ?></td>
                            <td><?php echo e($product->quantity); ?></td>
                            <td><?php echo e($product->price); ?></td>
                            <td><?php echo e($product->price * $product->quantity); ?></td>
                        </tr>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                </tbody>
            </table>
        </div>
        <div class="card-footer">
        </div>
    </div>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('css'); ?>
    <link rel="stylesheet" href="/css/admin_custom.css">
<?php $__env->stopSection(); ?>

<?php $__env->startSection('js'); ?>
    <?php echo \Livewire\Livewire::scripts(); ?>

<?php $__env->stopSection(); ?>

<?php echo $__env->make('adminlte::page', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\bodega\resources\views/admin/inputs/show.blade.php ENDPATH**/ ?>