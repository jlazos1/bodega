

<?php $__env->startSection('title', 'Arriendos'); ?>

<?php $__env->startSection('content_header'); ?>
    <h1>Nuevo Arriendo</h1>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('content'); ?>

    <div class="card">
        <div class="card-body">
            <?php echo Form::token(); ?>

            <?php echo Form::open(['route' => 'admin.loans.store', 'method' => 'post']); ?>


            <?php echo Form::label('customer_id', 'Cliente', ['class' => 'h5']); ?>

            <?php echo Form::select('customer_id', $customers, null, [
                'class' => 'form-control mb-2 customer-select',
                'placeholder' => 'Seleccione un Cliente',
            ]); ?>

            <?php $__errorArgs = ['customer_id'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                <small style="color: red"><?php echo e($message); ?></small><br>
            <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>

            <div class="mt-3">
                <div class="float-left mb-20" style='width: 49%'>

                    <?php echo Form::label('loan_date', 'Fecha Inicial', ['class' => 'h5']); ?>

                    <?php echo Form::date('loan_date', null, ['class' => 'form-control mb-2']); ?>

                    <?php $__errorArgs = ['loan_date'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                        <small style="color: red"><?php echo e($message); ?></small><br>
                    <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                </div>
                <div class="float-right" style='width: 49%'>

                    <?php echo Form::label('return_date', 'Fecha Final', ['class' => 'h5']); ?>

                    <?php echo Form::date('return_date', null, ['class' => 'form-control mb-2']); ?>

                    <?php $__errorArgs = ['return_date'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                        <small style="color: red"><?php echo e($message); ?></small><br>
                    <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                </div>
            </div>

            <?php echo Form::submit('Siguiente', ['class' => 'btn btn-primary mt-4 float-right']); ?>


            <?php echo Form::close(); ?>

        </div>
    </div>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('css'); ?>
    <link rel="stylesheet" href="/css/admin_custom.css">
<?php $__env->stopSection(); ?>

<?php $__env->startSection('js'); ?>
    <?php echo \Livewire\Livewire::scripts(); ?>

    <script>
        $(document).ready(function() {
            let select2 = $('.customer-select').select2();
            select2.data('select2').$selection.css('height', '38px');
        });
    </script>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('adminlte::page', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\bodega\resources\views/admin/loans/create.blade.php ENDPATH**/ ?>