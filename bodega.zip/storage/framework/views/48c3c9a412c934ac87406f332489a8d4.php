

<?php $__env->startSection('title', 'Mantenimientos'); ?>

<?php $__env->startSection('content_header'); ?>
    <h1>Editar Mantenimiento</h1>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('content'); ?>

    <div class="card">
        <div class="card-body">
            <?php echo Form::token(); ?>


            <?php echo Form::label('machine_id', 'Nombre Máquina', ['class' => 'h5']); ?>

            <?php echo Form::label('machine_name', $machine_name, ['class' => 'form-control mb-2']); ?>


            <?php echo Form::label('date', 'Fecha', ['class' => 'h5']); ?>

            <?php echo Form::label('date', \Carbon\Carbon::parse($maintenance->date)->format('d-m-Y'), ['class' => 'form-control mb-2']); ?>


            <?php echo Form::label('details', 'Detalles', ['class' => 'h5']); ?>

            <?php echo Form::textarea('details', $maintenance->details, ['class' => 'form-control mb-2', 'readonly' => 'readonly']); ?>

            <?php $__errorArgs = ['details'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                <small style="color: red"><?php echo e($message); ?></small><br>
            <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>

            <a href="<?php echo e(route('admin.maintenances.index')); ?>" class="btn btn-primary float-right">Volver</a>

            <?php echo Form::close(); ?>


        </div>
    </div>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('css'); ?>
    <link rel="stylesheet" href="/css/admin_custom.css">
<?php $__env->stopSection(); ?>

<?php $__env->startSection('js'); ?>
    <?php echo \Livewire\Livewire::scripts(); ?>


<?php $__env->stopSection(); ?>

<?php echo $__env->make('adminlte::page', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\bodega\resources\views/admin/maintenances/show.blade.php ENDPATH**/ ?>