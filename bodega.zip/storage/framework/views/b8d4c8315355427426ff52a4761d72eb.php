

<?php $__env->startSection('title', 'Entradas'); ?>

<?php $__env->startSection('content_header'); ?>
    <h1>Productos entrada</h1>
<?php $__env->stopSection(); ?>
<?php $__env->startSection('content'); ?>

    <div class="card pr-4 pl-4 pb-5">
        <?php echo Form::token(); ?>

        <?php echo Form::open(['route' => 'admin.detalles-inputs.store', 'method' => 'post']); ?>


        <?php echo Form::label('productos', 'Productos', ['class' => 'h5 display: block mt-4 mb-4']); ?>


        <?php echo Form::label('product_id', 'Nombre Producto', ['class' => 'h5']); ?>

        <?php echo Form::select('product_id', $products, null, [
            'class' => 'form-control mb-2 select-product',
            'placeholder' => 'Seleccione un producto',
        ]); ?>

        <?php $__errorArgs = ['product_id'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
            <small style="color: red"><?php echo e($message); ?></small><br>
        <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>


        <?php echo Form::label('quantity', 'Cantidad', ['class' => 'h5']); ?>

        <?php echo Form::number('quantity', null, ['class' => 'form-control mb-2']); ?>

        <?php $__errorArgs = ['quantity'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
            <small style="color: red"><?php echo e($message); ?></small><br>
        <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>


        <?php echo Form::label('price', 'Precio Unitario', ['class' => 'h5']); ?>

        <?php echo Form::number('price', null, ['class' => 'form-control mb-2']); ?>

        <?php $__errorArgs = ['price'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
            <small style="color: red"><?php echo e($message); ?></small><br>
        <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>


        <?php echo Form::hidden('input_id', $input->id, ['class' => 'form-control mb-2']); ?>


        <?php echo Form::submit('Agregar', ['class' => 'btn btn-primary mt-4']); ?>


        <?php echo Form::close(); ?>




        <div>
            <table class="table table-striped mt-5">
                <thead>
                    <tr>
                        <th>Nombre</th>
                        <th>Cantidad</th>
                        <th>P. Unitario</th>
                        <th>Total</th>
                        <th></th>
                    </tr>
                </thead>
                <tbody>
                    <?php $__currentLoopData = $productsAdd; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $product): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <tr>
                            <td><?php echo e($product->product_name); ?></td>
                            <td><?php echo e($product->quantity); ?></td>
                            <td><?php echo e($product->price); ?></td>
                            <td><?php echo e($product->price * $product->quantity); ?></td>
                            <td width="10px">
                                <form action="<?php echo e(route('admin.detalles-inputs.destroy', $product->id)); ?>" method="POST">
                                    <?php echo method_field('DELETE'); ?>
                                    <?php echo csrf_field(); ?>
                                    <button class="btn btn-danger fa fa-trash"></button>
                                </form>
                            </td>
                        </tr>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                </tbody>
            </table>
        </div>
        <div>
            <a href="<?php echo e(route('admin.inputs.index')); ?>" class="btn btn-danger float-right">Finalizar</a>
        </div>
    </div>
<?php $__env->stopSection(); ?>


<?php $__env->startSection('css'); ?>
    <link rel="stylesheet" href="/css/admin_custom.css">
    <script src="https://kit.fontawesome.com/3ace52d1a2.js" crossorigin="anonymous"></script>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('js'); ?>
    <?php echo \Livewire\Livewire::scripts(); ?>

    <script>
        $(document).ready(function() {
            let select2 = $('.select-product').select2();
            select2.data('select2').$selection.css('height', '38px');
        });
    </script>

<?php $__env->stopSection(); ?>

<?php echo $__env->make('adminlte::page', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\bodega\resources\views/livewire/admin/details-inputs-index.blade.php ENDPATH**/ ?>