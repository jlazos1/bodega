    <div>
        <div class="card">
            <div class="card-header">
                <input wire:model="search" type="text" class="form-control" placeholder="Filtrar">
            </div>

            <?php if($products_branch->count()): ?>
                <div class="card-body">
                    <table class="table table-striped">
                        <thead>
                            <tr>
                                <th>ID Producto</th>
                                <th>Nombre</th>
                                <th>Stock</th>
                                <th>Sucursal</th>
                            </tr>
                        </thead>
                        <tbody>
                            <?php $__currentLoopData = $products_branch; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $pr_br): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                <tr>
                                    <td><?php echo e($pr_br->product_id); ?></td>
                                    <td><?php echo e($pr_br->product_name); ?></td>
                                    <td><?php echo e($pr_br->quantity); ?></td>
                                    <td><?php echo e($pr_br->branch_name); ?></td>

                                </tr>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                        </tbody>
                    </table>
                </div>
                <div class="card-footer">
                    <?php echo e($products_branch->links()); ?>

                </div>
            <?php else: ?>
                <div class="card-body">
                    <strong>No hay registros</strong>
                </div>
            <?php endif; ?>

        </div>
    </div>
<?php /**PATH C:\xampp\htdocs\bodega\resources\views/livewire/admin/stock-branch-index.blade.php ENDPATH**/ ?>