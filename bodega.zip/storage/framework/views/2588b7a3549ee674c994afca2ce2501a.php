<?php if(session('info')): ?>
    <div class="alert alert-success">
        <strong>
            <?php echo e(session('info')); ?>

        </strong>
    </div>
<?php endif; ?>
<div>
    <div class="card">
        <div class="card-header">
            <input wire:model="search" type="text" class="form-control" placeholder="Filtrar">
        </div>


        <?php if($users->count()): ?>
            <div class="card-body">
                <table class="table table-striped table-users">
                    <thead>
                        <tr>
                            <th>ID</th>
                            <th>Nombre</th>
                            <th>Email</th>
                            <th>Sucursal</th>
                            <th></th>
                        </tr>
                    </thead>
                    <tbody>
                        <?php $__currentLoopData = $users; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $user): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <tr>
                                <td><?php echo e($user->id); ?></td>
                                <td><?php echo e($user->name); ?></td>
                                <td><?php echo e($user->email); ?></td>
                                <?php if($user->branch_name != null): ?>
                                    <td><?php echo e($user->branch_name); ?></td>
                                <?php else: ?>
                                    <td>Sin Asignar</td>
                                <?php endif; ?>

                                <td style="display: flex;" class="float-right">
                                    <?php if (app(\Illuminate\Contracts\Auth\Access\Gate::class)->check('admin.users.edit')): ?>
                                        <a href="<?php echo e(route('admin.users.edit', $user->id)); ?>"
                                            class="btn btn-primary fa fa-pen-to-square mr-2" title="Editar"></a>
                                            <a href="<?php echo e(route('admin.resetPassword', $user->id )); ?>" class="btn btn-danger fa fa-key" title="Reiniciar contraseña"></a>
                                    <?php endif; ?>
                                </td>
                            </tr>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    </tbody>
                </table>
            </div>
            <div class="card-footer">
                <?php echo e($users->links()); ?>

            </div>
        <?php else: ?>
            <div class="card-body">
                <strong>No hay registros</strong>
            </div>
        <?php endif; ?>

    </div>
</div>
<?php /**PATH C:\xampp\htdocs\bodega\resources\views/livewire/admin/users-index.blade.php ENDPATH**/ ?>