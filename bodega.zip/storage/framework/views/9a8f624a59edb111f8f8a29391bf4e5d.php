

<?php $__env->startSection('title', 'Arriendos'); ?>

<?php $__env->startSection('content_header'); ?>
    <h1>Arriendo</h1>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('content'); ?>

    <div class="card">
        <div class="card-body">
            <?php echo Form::label('customer_id', 'Cliente', ['class' => 'h5']); ?>

            <?php echo Form::label('customer_id', $customer_name, ['class' => 'form-control mb-2']); ?>


            <div class="mt-3">
                <div class="float-left mb-20" style='width: 49%'>

                    <?php echo Form::label('loan_date', 'Fecha Inicial', ['class' => 'h5']); ?>

                    <?php echo Form::label('loan_date', \Carbon\Carbon::parse($loan->loan_date)->format('d-m-Y'), [
                        'class' => 'form-control mb-2',
                    ]); ?>


                </div>
                <div class="float-right" style='width: 49%'>

                    <?php echo Form::label('return_date', 'Fecha Final', ['class' => 'h5']); ?>

                    <?php echo Form::label('return_date', \Carbon\Carbon::parse($loan->return_date)->format('d-m-Y'), [
                        'class' => 'form-control mb-2',
                    ]); ?>


                </div>
            </div>
        </div>

        <div class="card-body">
            <table class="table table-striped">
                <h2>Máquinas</h2>
                <thead>
                    <tr>
                        <th>ID</th>
                        <th>Nombre</th>
                    </tr>
                </thead>
                <tbody>
                    <?php $__currentLoopData = $machinesAdd; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $machine): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <tr>
                            <td><?php echo e($machine->machine_id); ?></td>
                            <td><?php echo e($machine->machine_name); ?></td>
                        </tr>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                </tbody>
            </table>
            <div class="card-footer">
                <?php echo e($machinesAdd->links()); ?>

            </div>

            <a href="<?php echo e(route('admin.loans.index')); ?>" class="btn btn-primary mt-4">Volver</a>
        </div>
    </div>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('css'); ?>
    <link rel="stylesheet" href="/css/admin_custom.css">
<?php $__env->stopSection(); ?>

<?php $__env->startSection('js'); ?>
    <?php echo \Livewire\Livewire::scripts(); ?>

<?php $__env->stopSection(); ?>

<?php echo $__env->make('adminlte::page', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\bodega\resources\views/admin/loans/show.blade.php ENDPATH**/ ?>