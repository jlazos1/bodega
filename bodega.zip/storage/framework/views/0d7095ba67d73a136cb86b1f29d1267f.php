

<?php $__env->startSection('title', 'Traslados'); ?>

<?php $__env->startSection('content_header'); ?>
    <h1>Traslado</h1>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('content'); ?>

    <div class="card">
        <div class="card-body">
            <?php echo Form::token(); ?>


            <?php echo Form::label('origin_branch_id', 'Sucursal Origen', ['class' => 'h5']); ?>

            <?php echo Form::label('origin_branch_id', $origin_name, ['class' => 'form-control mb-2']); ?>

            <?php echo Form::hidden('origin_branch_id', $relocation->origin, []); ?>


            <?php echo Form::label('destination_branch_id', 'Sucursal Destino', ['class' => 'h5']); ?>

            <?php echo Form::label('destination_branch_id', $destination_name, ['class' => 'form-control mb-2']); ?>


            <?php echo Form::label('date', 'Fecha', ['class' => 'h5']); ?>

            <?php echo Form::label('date', \Carbon\Carbon::parse($relocation->date)->format('d-m-Y'), [
                'class' => 'form-control mb-2',
            ]); ?>




            <div>
                <table class="table table-striped mt-5">
                    <thead>
                        <tr>
                            <th>ID</th>
                            <th>Nombre</th>
                            <th></th>
                        </tr>
                    </thead>
                    <tbody>
                        <?php $__currentLoopData = $machinesAdd; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $machine): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <tr>
                                <td><?php echo e($machine->machine_id); ?></td>
                                <td><?php echo e($machine->machine_name); ?></td>
                                <td width="10px">
                                </td>
                            </tr>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    </tbody>
                </table>
            </div>
            <div class="card-footer">
                <?php echo e($machinesAdd->links()); ?>

            </div>

            <a href="<?php echo e(route('admin.machines-relocations.index')); ?>" class="btn btn-primary mt-3">Volver</a>
        </div>
    </div>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('css'); ?>
    <link rel="stylesheet" href="/css/admin_custom.css">
<?php $__env->stopSection(); ?>

<?php $__env->startSection('js'); ?>
    <?php echo \Livewire\Livewire::scripts(); ?>


<?php $__env->stopSection(); ?>

<?php echo $__env->make('adminlte::page', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\bodega\resources\views/admin/relocations-machines/show.blade.php ENDPATH**/ ?>