<?php $__env->startSection('title', 'Traslados'); ?>

<?php $__env->startSection('content_header'); ?>
    <h1>Traslados</h1>
<?php $__env->stopSection(); ?>
<?php $__env->startSection('content'); ?>
    <?php if(session('error')): ?>
        <div class="alert alert-danger">
            <?php echo e(session('error')); ?>

        </div>
    <?php endif; ?>
    <?php if(session('correct')): ?>
        <div class="alert alert-success">
            <?php echo e(session('correct')); ?>

        </div>
    <?php endif; ?>
    <div class="card pr-4 pl-4 pb-5">
        <?php echo Form::token(); ?>

        <?php echo Form::open(['route' => 'admin.detalles-relocations.store', 'method' => 'post']); ?>


        <?php echo Form::label('assets', 'Activos', ['class' => 'h5 display: block mt-4 mb-4']); ?>


        <?php echo Form::label('asset_id', 'Nombre Activo', ['class' => 'h5']); ?>

        <?php echo Form::select('asset_id', $assets, null, [
            'class' => 'form-control mb-2 select-asset',
            'multiple' => 'multiple',
            'name' => 'seleccion[]',
        ]); ?>


        <?php echo Form::hidden('relocation_id', $relocation_id, ['class' => 'form-control mb-2']); ?>


        <?php echo Form::submit('Agregar', ['class' => 'btn btn-primary mt-4']); ?>


        <?php echo Form::close(); ?>


        <div>
            <table class="table table-striped mt-5">
                <thead>
                    <tr>
                        <th>ID</th>
                        <th>Nombre</th>
                        <th></th>
                    </tr>
                </thead>
                <tbody>
                    <?php $__currentLoopData = $assetsAdd; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $asse): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <tr>
                            <td><?php echo e($asse->asset_id); ?></td>
                            <td><?php echo e($asse->asset_name); ?></td>
                            <td width="10px">
                                <form action="<?php echo e(route('admin.detalles-outputs.destroy', $asse->id)); ?>" method="POST">
                                    <?php echo method_field('DELETE'); ?>
                                    <?php echo csrf_field(); ?>
                                    <button class="btn btn-danger fa fa-trash"></button>
                                </form>
                            </td>
                        </tr>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                </tbody>
            </table>
        </div>
        <div>
            <a href="<?php echo e(route('admin.relocations.index')); ?>" class="btn btn-danger float-right">Finalizar</a>
        </div>
    </div>
<?php $__env->stopSection(); ?>


<?php $__env->startSection('css'); ?>
    <link rel="stylesheet" href="/css/admin_custom.css">
    <script src="https://kit.fontawesome.com/3ace52d1a2.js" crossorigin="anonymous"></script>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('js'); ?>
    <?php echo \Livewire\Livewire::scripts(); ?>

    <script>
        $(document).ready(function() {
            $('.select-asset').select2();
        });
    </script>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('adminlte::page', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\bodega\resources\views/livewire/admin/details-relocations-index.blade.php ENDPATH**/ ?>