<?php if(session('info')): ?>
    <div class="alert alert-success">
        <strong>
            <?php echo e(session('info')); ?>

        </strong>
    </div>
<?php endif; ?>

<div>
    <div class="card">
        <div class="card-header">
            <input wire:model="search" type="text" class="form-control mb-2" placeholder="Filtrar">
            <div class="mt-3">
                <div class="float-left mb-20" style='width: 49%'>
                    <label for="">Fecha Inicial</label>
                    <input wire:model="from_date" type="date" class="form-control mb-2" placeholder="Filtrar">
                </div>
                <div class="float-right" style='width: 49%'>
                    <label for="">Fecha Final</label>
                    <input wire:model="to_date" type="date" class="form-control" placeholder="Filtrar">
                </div>
            </div>
        </div>


        <?php if($inputs->count()): ?>
            <div class="card-body">
                <table class="table table-striped">
                    <thead>
                        <tr>
                            <th>ID</th>
                            <th>Proveedor</th>
                            <th>Sucursal</th>
                            <th>Tipo Doc.</th>
                            <th>Nro Doc.</th>
                            <th>Fecha</th>
                            <th>Monto Neto</th>
                            <th></th>
                        </tr>
                    </thead>
                    <tbody>
                        <?php $__currentLoopData = $inputs; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $input): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <tr>
                                <td><?php echo e($input->id); ?></td>
                                <td><?php echo e($input->provider_name); ?></td>
                                <td><?php echo e($input->branch_name); ?></td>
                                <td><?php echo e($input->document_type_name); ?></td>
                                <td><?php echo e($input->doc_number); ?></td>
                                <td><?php echo e(\Carbon\Carbon::parse($input->date)->format('d-m-Y')); ?></td>
                                <td><?php echo e($input->net_amount); ?></td>
                                <td style="display: flex;" class="float-right">
                                    <?php if (app(\Illuminate\Contracts\Auth\Access\Gate::class)->check('admin.inputs.show')): ?>
                                        <a href="<?php echo e(route('admin.inputs.show', [$input->id])); ?>"
                                            class="btn btn-primary fa fa-eye mr-2" title="Ver"></a>
                                    <?php endif; ?>
                                    <?php if (app(\Illuminate\Contracts\Auth\Access\Gate::class)->check('admin.inputs.edit')): ?>
                                        <a href="<?php echo e(route('admin.inputs.edit', [$input->id])); ?>"
                                            class="btn btn-primary fa fa-pen-to-square" title="Editar"></a>
                                    <?php endif; ?>
                                </td>
                            </tr>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    </tbody>
                </table>
            </div>
            <div class="card-footer">
                <?php echo e($inputs->links()); ?>

            </div>
        <?php else: ?>
            <div class="card-body">
                <strong>No hay registros</strong>
            </div>
        <?php endif; ?>
    </div>
</div>
<?php /**PATH C:\xampp\htdocs\bodega\resources\views/livewire/admin/inputs-index.blade.php ENDPATH**/ ?>