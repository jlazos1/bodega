<a href="/">
    <img src="img/logognv2.png" alt="">
</a>
<?php /**PATH C:\xampp\htdocs\bodega\resources\views/components/authentication-card-logo.blade.php ENDPATH**/ ?>