<div class="visible-print text-center">
    <img src="data:image/png;base64, <?php echo $qrcode; ?>">
    <div class="border"> 
        <h1 class="text-center"><?php echo e($url); ?></h1>
    </div>
</div>
<?php /**PATH C:\xampp\htdocs\bodega\resources\views/qrcode.blade.php ENDPATH**/ ?>