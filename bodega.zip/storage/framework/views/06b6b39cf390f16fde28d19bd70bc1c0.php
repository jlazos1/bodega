

<?php $__env->startSection('title', 'Movimiento Interno'); ?>

<?php $__env->startSection('content_header'); ?>
    <h1>Nuevo Movimiento Interno</h1>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('content'); ?>

    <div class="card">
        <div class="card-body">
            <?php echo Form::token(); ?>

            <?php echo Form::open(['route' => 'admin.outputs.store', 'method' => 'post']); ?>


            <?php echo Form::label('origin_branch_id', 'Sucursal Origen', ['class' => 'h5']); ?>

            <?php echo Form::select('origin_branch_id', $branches, null, [
                'class' => 'form-control mb-2 select-branch',
                'placeholder' => 'Seleccione una Sucursal',
            ]); ?>

            <?php $__errorArgs = ['origin_branch_id'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                <small style="color: red"><?php echo e($message); ?></small><br>
            <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>

            <?php echo Form::label('destination_branch_id', 'Sucursal Destino', ['class' => 'h5']); ?>

            <?php echo Form::select('destination_branch_id', $branches, null, [
                'class' => 'form-control mb-2 select-branch2',
                'placeholder' => 'Seleccione una Sucursal',
            ]); ?>

            <?php $__errorArgs = ['destination_branch_id'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                <small style="color: red"><?php echo e($message); ?></small><br>
            <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>

            <?php echo Form::label('date', 'Fecha', ['class' => 'h5']); ?>

            <?php echo Form::date('date', null, ['class' => 'form-control mb-2']); ?>

            <?php $__errorArgs = ['date'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                <small style="color: red"><?php echo e($message); ?></small><br>
            <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>

            <?php echo Form::submit('Siguiente', ['class' => 'btn btn-primary mt-4']); ?>


            <?php echo Form::close(); ?>

        </div>
    </div>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('css'); ?>
    <link rel="stylesheet" href="/css/admin_custom.css">
<?php $__env->stopSection(); ?>

<?php $__env->startSection('js'); ?>
    <?php echo \Livewire\Livewire::scripts(); ?>

    <script>
        $(document).ready(function() {
            let select2 = $('.select-branch').select2();
            select2.data('select2').$selection.css('height', '38px');
        });
        $(document).ready(function() {
            let select2 = $('.select-branch2').select2();
            select2.data('select2').$selection.css('height', '38px');
        });
    </script>

<?php $__env->stopSection(); ?>

<?php echo $__env->make('adminlte::page', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\bodega\resources\views/admin/outputs/create.blade.php ENDPATH**/ ?>