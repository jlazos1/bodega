<?php if(session('info')): ?>
    <div class="alert alert-success">
        <strong>
            <?php echo e(session('info')); ?>

        </strong>
    </div>
<?php endif; ?>
<div>
    <div class="card">
        <div class="card-header">
            <input wire:model="search" type="text" class="form-control" placeholder="Filtrar">
        </div>


        <?php if($games->count()): ?>
            <div class="card-body">
                <table class="table table-striped">
                    <thead>
                        <tr>
                            <th>ID</th>
                            <th>Nombre</th>
                            <th></th>
                        </tr>
                    </thead>
                    <tbody>
                        <?php $__currentLoopData = $games; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $game): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <tr>
                                <td><?php echo e($game->id); ?></td>
                                <td><?php echo e($game->name); ?></td>
                                <td width="10px">
                                    <?php if (app(\Illuminate\Contracts\Auth\Access\Gate::class)->check('admin.game-boards.edit')): ?>
                                        <a href="<?php echo e(route('admin.game-boards.edit', $game->id)); ?>"
                                            class="btn btn-primary fa fa-pen-to-square"></a>
                                    <?php endif; ?>
                                </td>
                            </tr>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    </tbody>
                </table>
            </div>
            <div class="card-footer">
                <?php echo e($games->links()); ?>

            </div>
        <?php else: ?>
            <div class="card-body">
                <strong>No hay registros</strong>
            </div>
        <?php endif; ?>

    </div>
</div>
<?php /**PATH C:\xampp\htdocs\bodega\resources\views/livewire/admin/games-boards-index.blade.php ENDPATH**/ ?>