

<?php $__env->startSection('title', 'Máquinas'); ?>

<?php $__env->startSection('content_header'); ?>
    <h1>Máquina</h1>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('content'); ?>

    <div class="card">
        <!-- INFORMACIÓN DE LA MÁQUINAS -->
        <div class="card-body">
            <?php echo Form::label('name', 'Nombre', ['class' => 'h5']); ?>

            <?php echo Form::label('name', $machine->name, ['class' => ' form-control h5 mb-2']); ?>


            <?php echo Form::label('value', 'Valor Monetario', ['class' => 'h5']); ?>

            <?php echo Form::label('name', $machine->value, ['class' => 'form-control h5 mb-2']); ?>


            <?php echo Form::label('games_board_id', 'Tarjeta de Juego', ['class' => 'h5']); ?>

            <?php echo Form::label('name', $game_board, ['class' => 'form-control h5 mb-2']); ?>


            <?php echo Form::label('branch_id', 'Sucursal', ['class' => 'h5 mt-2']); ?>

            <?php echo Form::label('name', $branch_name, ['class' => 'form-control h5 mb-2']); ?>

        </div>
    </div>

    <!-- INFORMACIÓN DE TRASLADOS -->
    <div class="card">
        <div class="card-header">
            <h3 class="card-title">Traslados</h3>
            <div class="card-tools">
                <button type="button" class="btn btn-tool" data-card-widget="collapse" title="Collapse">
                    <i class="fas fa-minus"></i>
                </button>
            </div>
        </div>
        <div class="card-body" style="display: block;">
            <div class="card-body">
                <?php if($relocations->count()): ?>
                    <table class="table table-striped">
                        <thead>
                            <tr>
                                <th>ID Traslado</th>
                                <th>Fecha</th>
                                <th>Origen</th>
                                <th>Destino</th>
                            </tr>
                        </thead>
                        <tbody>
                            <?php $__currentLoopData = $relocations; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $relo): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                <tr>
                                    <td><?php echo e($relo->id); ?></td>
                                    <td><?php echo e($relo->date); ?></td>
                                    <td><?php echo e($relo->origin_name); ?></td>
                                    <td><?php echo e($relo->destination_name); ?></td>
                                </tr>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                        </tbody>
                    </table>
                <?php else: ?>
                    <div class="card-body">
                        <strong>No hay registros</strong>
                    </div>
                <?php endif; ?>
            </div>
        </div>
    </div>


    <!-- INFORMACIÓN DE ARRIENDOS -->
    <div class="card">
        <div class="card-header">
            <h3 class="card-title">Arriendos</h3>
            <div class="card-tools">
                <button type="button" class="btn btn-tool" data-card-widget="collapse" title="Collapse">
                    <i class="fas fa-minus"></i>
                </button>

            </div>
        </div>
        <div class="card-body" style="display: block;">
            <div class="card-body">
                <?php if($loans->count()): ?>
                    <table class="table table-striped">
                        <thead>
                            <tr>
                                <th>ID Arriendo</th>
                                <th>Cliente</th>
                                <th>Fecha Inicial</th>
                                <th>Fecha Final</th>
                                <th>Estado</th>
                            </tr>
                        </thead>
                        <tbody>
                            <?php $__currentLoopData = $loans; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $loan): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                <tr>
                                    <td><?php echo e($loan->id); ?></td>
                                    <td><?php echo e($loan->customer_name); ?></td>
                                    <td><?php echo e(\Carbon\Carbon::parse($loan->loan_date)->format('d-m-Y')); ?></td>
                                    <td><?php echo e(\Carbon\Carbon::parse($loan->return_date)->format('d-m-Y')); ?></td>
                                    <td><?php echo e($loan->loan_state_name); ?></td>
                                </tr>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                        </tbody>
                    </table>
                <?php else: ?>
                    <div class="card-body">
                        <strong>No hay registros</strong>
                    </div>
                <?php endif; ?>
            </div>
        </div>
    </div>

    <!-- INFORMACIÓN DE MANTENIMIENTOS -->
    <div class="card">
        <div class="card-header">
            <h3 class="card-title">Mantenimientos</h3>
            <div class="card-tools">
                <button type="button" class="btn btn-tool" data-card-widget="collapse" title="Collapse">
                    <i class="fas fa-minus"></i>
                </button>

            </div>
        </div>
        <div class="card-body" style="display: block;">
            <div class="card-body">
                <?php if($maintenances->count()): ?>
                    <table class="table table-striped">
                        <thead>
                            <tr>
                                <th>ID</th>
                                <th>Fecha</th>
                                <th>Encargado</th>
                            </tr>
                        </thead>
                        <tbody>
                            <?php $__currentLoopData = $maintenances; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $maintenance): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                <tr>
                                    <td><?php echo e($maintenance->id); ?></td>
                                    <td><?php echo e(\Carbon\Carbon::parse($maintenance->date)->format('d-m-Y')); ?></td>
                                    <td><?php echo e($maintenance->user_name); ?></td>
                                </tr>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                        </tbody>
                    </table>
                <?php else: ?>
                    <div class="card-body">
                        <strong>No hay registros</strong>
                    </div>
                <?php endif; ?>
            </div>
        </div>
    </div>

<?php $__env->stopSection(); ?>

<?php $__env->startSection('css'); ?>
    <link rel="stylesheet" href="/css/admin_custom.css">
<?php $__env->stopSection(); ?>

<?php $__env->startSection('js'); ?>
    <?php echo \Livewire\Livewire::scripts(); ?>

<?php $__env->stopSection(); ?>

<?php echo $__env->make('adminlte::page', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\bodega\resources\views/admin/machines/show.blade.php ENDPATH**/ ?>