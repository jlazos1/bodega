

<?php $__env->startSection('title', 'Entradas'); ?>

<?php $__env->startSection('content_header'); ?>
    <?php if (app(\Illuminate\Contracts\Auth\Access\Gate::class)->check('admin.inputs.create')): ?>
        <a href="<?php echo e(route('admin.inputs.create')); ?>" class="btn btn-primary mb-2 float-right">Nuevo</a>
    <?php endif; ?>
    <h1>Entradas</h1>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('content'); ?>
    <?php
if (! isset($_instance)) {
    $html = \Livewire\Livewire::mount('admin.inputs-index')->html();
} elseif ($_instance->childHasBeenRendered('vr6DLtu')) {
    $componentId = $_instance->getRenderedChildComponentId('vr6DLtu');
    $componentTag = $_instance->getRenderedChildComponentTagName('vr6DLtu');
    $html = \Livewire\Livewire::dummyMount($componentId, $componentTag);
    $_instance->preserveRenderedChild('vr6DLtu');
} else {
    $response = \Livewire\Livewire::mount('admin.inputs-index');
    $html = $response->html();
    $_instance->logRenderedChild('vr6DLtu', $response->id(), \Livewire\Livewire::getRootElementTagName($html));
}
echo $html;
?>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('css'); ?>
    <link rel="stylesheet" href="/css/admin_custom.css">
    <script src="https://kit.fontawesome.com/3ace52d1a2.js" crossorigin="anonymous"></script>

<?php $__env->stopSection(); ?>

<?php $__env->startSection('js'); ?>
    <?php echo \Livewire\Livewire::scripts(); ?>

<?php $__env->stopSection(); ?>

<?php echo $__env->make('adminlte::page', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\bodega\resources\views/admin/inputs/index.blade.php ENDPATH**/ ?>